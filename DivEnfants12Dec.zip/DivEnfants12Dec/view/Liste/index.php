<?php $this->title = "Liste de tous les jeux"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>
<h3>Liste de tous les jeux disponibles</h3>
<div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputIdjeux">JEUX</label>
             
 <FORM>
<SELECT name="JEUX" size="1">
<?php foreach ($jeux as $Jeux): ?>
 <option value="<?= $this->clean($Jeux['JEUX_ID'])?>"> <?= $this->clean($Jeux['JEUX_NOM']) ?> <?= $this->clean($Jeux['JEUX_ID'])?></option>

<?php endforeach; ?>

</SELECT>
</FORM>




