<?php $this->title = "Accueil"; ?>

   <p>Nous vous souhaitons la Bienvenue</p>
    <a href="login/index">Entrez dans le site</a>
