<div class="dropdown">
  <button class="btn btn-secondary dropdown-toggle" type="button" data-toggle="dropdown">
    Jeux
  </button>
  <div class="dropdown-menu">
    <a class="dropdown-item" href="#">Dompteurs</a>
    <a class="dropdown-item" href="#">Zoos</a>
    <a class="dropdown-item" href="#">Chasseurs</a>
  </div>
</div>