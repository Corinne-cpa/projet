<?php $this->title = "Liste des parents"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>
<h3>Liste des parents pour recupérer l'ID</h3>
<div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputIdenfant">PARENTS(ID & Nom Prenom) </label>
            <FORM>
<SELECT name="JEUX" size="1">
<?php foreach ($parent as $Parents): ?>
    <option value="<?= $this->clean($Parents['PARENT_ID'])?>"> <?= $this->clean($Parents['PARENT_ID'])?> <?= $this->clean($Parents['PARENT_NOM']) ?> <?= $this->clean($Parents['PARENT_PRENOM']) ?></option>

<?php endforeach; ?>



</SELECT>
</FORM>