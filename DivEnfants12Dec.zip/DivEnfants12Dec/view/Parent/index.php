<p><a href="login/deconnecter">Déconnexion</a></p>
<h2>Bienvenue sur le site de divertissement des enfants.
    Vous êtes connecté en tant que parent: </h2>

Vous pouvez: 
<form>
   
    <br><button type="button" ><p><a href='parent/liste'>Récupérer votre ID avant d'ajouter un enfant</button></br>
   <br><button type="button" ><p><a href='enfants/index'>Ajouter un enfant</button></br>
   <br><button type="button" ><p><a href='enfants/liste'>Liste de tous les enfants</button></br>
   <br><button type="button" ><p><a href='orgjeux/liste'>Liste des jeux organisés</button></br>
   <br> <button type="button" ><p><a href='participe'>Inscription aux jeux organisés</button></br>
   
   
</form>


