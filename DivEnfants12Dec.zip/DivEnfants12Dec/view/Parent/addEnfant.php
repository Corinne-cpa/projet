<p><a href="login/deconnecter">Déconnexion</a></p>
<h3>Ajouter un enfant</h3>
<form>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputNom">Nom</label>
            <input type="text" class="form-control" id="inputNom" name="inputNom">
        </div>
        <div class="form-group col-md-6">
            <label for="inputprenom">Prénom</label>
            <input type="text" class="form-control" id="inputprenom" name="inputprenom">
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputDn">Date de naissance</label>
            <input type="date" class="form-control" id="inputDn" name="inputDn">
        </div>
    </div>
    
    <button type="submit" class="btn btn-primary">Ajouter enfant</button>
</form>