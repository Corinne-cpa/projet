<p><a href="login/deconnecter">Déconnexion</a></p>
<h2>Bienvenue sur le site de divertissement des enfants.
    Vous êtes connecté en tant que l'administateur du site</h2>
Les actions de l'administrateur: 
<form>
   
    
   <!-- <br><button type="button" ><p><a href='enfants/index'>Ajouter un enfant</button></br> -->
     <br><button type="button" ><p><a href='jeux/index'>Ajouter des jeux</button></br>
     <br><button type="button" ><p><a href='liste/index'>Lister tous les jeux </button></br>
     <br> <button type="button" ><p><a href='orgjeux/index'>Ajouter les jeux organisés</button></br>
      <br> <button type="button" ><p><a href='orgjeux/liste'>Lister les jeux organisés</button></br>
      <br> <button type="button" ><p><a href='enfants/liste'>Lister tous les enfants de la base</button></br>
      <br><button type="button" ><p><a href='parent/liste'>Lister des parents</button></br>
      <br><button type="button" ><p><a href='participe/liste'>Lister les participants de tous les jeux</button></br>
        <br><button type="button" >Lister les participants d'un jeu</button></br>
       <br><button type="button" >Lister nombre total des enfants d'un parent</button></br>
      <br><button type="button" >Lister un parent</button></br>
    <br> <button type="button" >Modifier un parent</button></br>
   <br><button type="button" >Modifier les jeux </button></br>
    <br><button type="button" >Modifier les jeux organisés</button></br>
  
  
</form>

