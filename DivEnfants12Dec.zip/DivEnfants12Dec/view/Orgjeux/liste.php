<?php $this->title = "Liste de tous les jeux organisés"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>
<h3>Liste de tous les jeux organisés</h3>
<div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputIdjeux">JEUX_ORGANISES(Jeu, date et ID)</label>
            <FORM>
<SELECT name="JEUX" size="1">
<?php foreach ($orgjeux as $Orgjeux): ?>
    <option value="<?= $this->clean($Orgjeux['ORGJEUX_ID'])?>"> <?= $this->clean($Orgjeux['ORGJEUX_JEUX']) ?> <?= $this->clean($Orgjeux['ORGJEUX_DATE'])?>"> <?= $this->clean($Orgjeux['ORGJEUX_ID'])?></option>
<?php endforeach; ?>
</SELECT>
</FORM>
    
 