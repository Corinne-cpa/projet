<?php $this->title = "Page de confirmation"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>

<h3>Votre enfant a bien été enregistré</h3
<p>Cliquez <a href="enfants"> Ici </a> pour enregistrer un autre enfant </p>
<p>Cliquez <a href="enfants/liste"> Ici </a> pour recupérer l'ID de l'enfant à ajouter à un jeu </p>
<p>Cliquez <a href="orgjeux/liste"> Ici </a> pour récuperer l'ID d'un jeu organisé </p>
<p>Cliquez <a href="participe"> Ici </a> pour ajouter un enfant aux jeux organisés </p