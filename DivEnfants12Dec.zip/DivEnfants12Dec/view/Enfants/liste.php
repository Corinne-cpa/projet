<?php $this->title = "Liste de tous les enfants"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>
<h3>Liste de tous les enfants</h3>
<div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputIdenfant">ENFANTS(ID, nom&prenom et ID parent)</label>
            <FORM>
<SELECT name="JEUX" size="1">
<?php foreach ($enfant as $Enfants): ?>
    <option value="<?= $this->clean($Enfants['ENFANT_ID'])?>"> <?= $this->clean($Enfants['ENFANT_ID'])?> <?= $this->clean($Enfants['ENFANT_NOM']) ?> <?= $this->clean($Enfants['ENFANT_PRENOM']) ?> <?= $this->clean($Enfants['ENFANT_PARENT']) ?></option>

<?php endforeach; ?>



</SELECT>
</FORM>