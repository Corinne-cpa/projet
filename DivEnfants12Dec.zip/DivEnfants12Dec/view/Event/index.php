<?php $this->title = "Evenements"; ?>

    <p><?= $events ?></p>
