<?php $this->title = "Page de confirmation ajout participant aux  jeux"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>

<h3>Le participant a bien été ajouté</h3
<p>Cliquez <a href="participe"> Ici </a> pour ajouter un autre enfant </p>
<p>Cliquez <a href="participe/liste"> Ici </a> pour voir la liste des participants </p