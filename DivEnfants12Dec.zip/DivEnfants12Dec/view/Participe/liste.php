<?php $this->title = "Liste des participants"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>
<h3>Liste des participants aux jeux</h3>
<?php foreach ($participe as $Participe): ?>

<?= "ID ENF:"?>
<?= $this->clean($Participe['PARTICIPE_ENF']) ?> </br>
<?= "ID JEUX ORGANISE:"?>
<?= $this->clean($Participe['PARTICIPE_ORG']) ?> </br>
<?php endforeach; ?>
    