<?php $this->title = "Page de connexion"; ?>

<h3>Votre inscription a été effectuée avec succès</h3
<p>Cliquez <a href="login"> Ici </a> pour vous connecter </p> 
