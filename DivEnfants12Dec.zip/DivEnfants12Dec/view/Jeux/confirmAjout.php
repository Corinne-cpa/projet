<?php $this->title = "Page de confirmation d'ajout"; ?>
<p><a href="login/deconnecter">Déconnexion</a></p>

<h3>Le jeu a bien été ajouté</h3
<p>Cliquez <a href="jeux"> Ici </a> pour ajouter un autre jeu </p>
<p>Cliquez <a href="liste"> Ici </a> pour voir la liste des jeux  </p>