<?php

require_once 'framework/Controller.php';
require_once 'model/Parents.php';
require_once 'model/Enfants.php';
require_once 'framework/Session.php';

/**
 * Contrôleur des actions liées aux parents
 *
 */
class ControllerParent extends Controller {

    private $parent;

    /**
     * Constructeur 
     */
    public function __construct() {
        $this->parent = new Parents();
    }

    // 
    public function index() {
        $this->generateView();
    }
     // Génerer la vue d'affichage des information des parents
    public function liste() {
         $parent = $this->parent->getParents();
        $this->generateView(array('parent' => $parent));
       
    }
    
    public function getParents (){
         $this->generateView();
    
        
    }
    /**
     * Ajouter un enfant
     *
    public function addEnfant(){
        $this->generateView();
    }
    
    **/
    

    


//Enregistrement d'un nouveau parent
    public function record() {
        $nom = $_POST['PARENT_NOM'];
        $prenom = $_POST['PARENT_PRENOM'];
        $adresse = $_POST['PARENT_ADRESSE'];
        $tel = $_POST['PARENT_TEL'];
        $email = $_POST['PARENT_EMAIL'];
        $mdp = $_POST['PARENT_MDP'];
        
        $this->parent->record($nom, $prenom, $adresse, $tel, $email,  $mdp);
        $this->generateView();
    }
    // Charger les éléments du formulaire de connexion dans des variables, ensuite appeler la methode connect 
    //dans le modèle model/Parents.php
    public function connect() {
        if(isset($_POST) && !empty($_POST)) {
            $email = $_POST['PARENT_EMAIL'];
            $mdp = $_POST['PARENT_MDP'];
            $result = $this->parent->connect($email, $mdp);

            /*$_SESSION["login"] = $login;*/
            $this->redirect("home");
            
            /*if (!empty($result)) {
                $_SESSION["login"] = $login;
                $this->redirect("home");
            } else {
                $this->generateView();
            }*/
        }/* Affcher la page d'acceuil home/index.php si les paramètres de connexion ne sont pas valides*/
        else 
            $this->generateView();
    }
}